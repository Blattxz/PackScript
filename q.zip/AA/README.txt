This script pack was made from EpicalBringer

the scripts in this pack are all public means nothing is private 

scripts taken from big exploiters such as Erased citizen/SonicElijahmania 